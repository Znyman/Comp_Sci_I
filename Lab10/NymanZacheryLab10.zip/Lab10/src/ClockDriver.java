/**
 * Lab 10
 * @author Zachery Nyman
 * 19 October 2016
 */
public class ClockDriver {

	public static void main(String[] args) {
		
		Clock c1 = new Clock();
		for (int time = 0; time < 1418; time++)
		{
		c1.displayTime();
		c1.tick();
		}
	}

}
