/**
 * Lab 10
 * @author Zachery Nyman
 * 19 October 2016
 */
import java.text.DecimalFormat;

public class Clock {
	private int hour = 00;
	private int minute = 00;
	
	DecimalFormat myFormatter = new DecimalFormat ("00");
	
	public void displayTime()
	{
		System.out.println(myFormatter.format(hour) + ":" + myFormatter.format(minute));
	}
	
	public void tick()
	{
		if (minute < 59)
		{
			minute++;
		}
		else {
			hour++;
			if (hour > 23)
			{
				hour = 00;
			}
			minute = 00;
			System.out.println(myFormatter.format(hour) + ":" + myFormatter.format(minute));
			minute++;
		}
		
	}
	public void reset()
	{
		hour = 00;
		minute = 00;
		System.out.println(myFormatter.format(hour) + ":" + myFormatter.format(minute));
	}
}
