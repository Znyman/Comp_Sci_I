/**
 * 
 * @author Zachery Nyman
 * Lab 1
 * September 14, 2016
 *
 */
public class Introduction {
	public static void main(String[] args) {
		System.out.println("Zachery Nyman");
		System.out.println("Rota,Spain");
		System.out.println("Applied Computing");
		System.out.println("Number of First Year Students at DU: approximately 1425");
		System.out.println("Number of M&M candies produced each day: 400,000,000");
		int candy = 400000000/1425;
		System.out.println("Number of M&M candies per First Year Student:" + candy);
	}

}
